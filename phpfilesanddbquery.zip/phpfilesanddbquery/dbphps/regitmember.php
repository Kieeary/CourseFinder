<?php 

    error_reporting(E_ALL); 
    ini_set('display_errors',1); 

    include('dbcon.php');

	// post방식으로 가져왔는가?
    if( $_SERVER['REQUEST_METHOD'] == 'POST') {

        // 안드로이드 코드의 postParameters 변수에 적어준 이름을 통해서 전달 받음

        $mi_id=$_POST['id'];
        $mi_pwd=$_POST['password'];
		$mi_name = $_POST['name'];
		$mi_phone = $_POST['phone'];
		$mi_birth = $_POST['birth'];
		$mi_gender = $_POST['gender'];
        try{		
			$stmt = $con->prepare('INSERT INTO MemberInfo(mi_id, mi_pwd, mi_name, mi_phone, mi_birth, mi_gender) VALUES(:mi_id, :mi_pwd, :mi_name, :mi_phone, :mi_birth, :mi_gender)');
			$stmt->bindParam(':mi_id', $mi_id);
			$stmt->bindParam(':mi_pwd', $mi_pwd);
			$stmt->bindParam(':mi_name', $mi_name);
			$stmt->bindParam(':mi_phone', $mi_phone);
			$stmt->bindParam(':mi_birth', $mi_birth);
			$stmt->bindParam(':mi_gender', $mi_gender);
					
			// SQL문을 실행하여 데이터를 MySQL 서버의 MemberInfo 테이블에 저장
			if($stmt->execute()){
					echo  "1";
			}else{
					echo "-1";
			}		 
				
        }catch(PDOException $e) {
                die("Database error: " . $e->getMessage()); 
         }
    }
?>
