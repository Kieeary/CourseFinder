<?php  
error_reporting(E_ALL); 
ini_set('display_errors',1); 

include('dbcon.php');

//POST 값을 읽어온다.
$id= $_POST['id'];


$sql="select * from MemberInfo where mi_id = '$id'";
$stmt = $con->prepare($sql);
$stmt->execute();
if ($stmt->rowCount() > 0){
	die("-1");
}else{
	echo "1";
}

?>