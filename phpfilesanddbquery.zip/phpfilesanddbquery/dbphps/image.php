<?php
  include('dbcon.php');

	if(isset($_POST['name'])){
		$name = $_POST['name'];
	}

	if(isset($_POST['idx'])){
		$idx = $_POST['idx'];
	}

    $file_path = 'C:/xampp/htdocs/uploads/'.$name.'.jpg';
 
    // $file_path = $file_path.basename( $_FILES['uploaded_file']['name']);
	
    if(move_uploaded_file($_FILES['uploaded_file']['tmp_name'], $file_path)) {
		try{
			$stmt = $con->prepare('INSERT INTO person(name, country) VALUES(:name, :idx)');
			$stmt->bindParam(':name', $name);
			$stmt->bindParam(':idx', $idx);
					
			// SQL문을 실행하여 데이터를 MySQL 서버의 person 테이블에 저장
			if($stmt->execute()){
					$successMSG = "새로운 사용자를 추가했습니다.";
			}else{
					$errMSG = "사용자 추가 에러";
			}
		}catch (PDOException $e) {
                die("Database error: " . $e->getMessage()); 
		}
        echo "success";
    } else{
        echo $file_path;
    }
 ?>

