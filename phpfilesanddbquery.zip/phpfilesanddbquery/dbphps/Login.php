<?php  
error_reporting(E_ALL); 
ini_set('display_errors',1); 

include('dbcon.php');

//POST 값을 읽어온다.
$id=$_POST['id'];
$password = isset($_POST['password']) ? $_POST['password'] : '';

if ($id != "" ){ 
    $sql="select * from MemberInfo where mi_id = '$id' and mi_pwd ='$password' and mi_isact='y'";
	// like'%$id%'"
    $stmt = $con->prepare($sql);
    $stmt->execute();
    if ($stmt->rowCount() == 0){
		die("failed");
	}else{
		$data = array();
        while($row=$stmt->fetch(PDO::FETCH_ASSOC)){
			// FETCH_ASSOC는 행의 값들을 가져올 수 있다.
			extract($row);
				array_push($data, 
				array(
				'mi_id'=>$row["mi_id"],
				'mi_name'=>$row["mi_name"],
				'mi_birth'=>$row["mi_birth"],
				'mi_phone'=>$row["mi_phone"],
				'mi_gender'=>$row["mi_gender"],
				'mi_register'=>$row["mi_register"]
			));
		}
		 header('Content-Type: application/json; charset=utf8');
         $json = json_encode(array("results"=>$data), JSON_PRETTY_PRINT+JSON_UNESCAPED_UNICODE);
         echo $json;
	}
}
?>

