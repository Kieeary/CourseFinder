<?php  
    error_reporting(E_ALL); 
    ini_set('display_errors',1); 
    include('dbcon.php');

	// post방식으로 가져왔는가?
    if( $_SERVER['REQUEST_METHOD'] == 'POST') {

        // 안드로이드 코드의 postParameters 변수에 적어준 이름을 통해서 전달 받음

        $ci_name=$_POST['name'];
        $ci_info=$_POST['info'];
		$ci_price = $_POST['price'];
		$ci_img = $_POST['img'];
		$mi_id = $_POST['miid'];
		$ci_cata = $_POST['ci_cata'];

		try{		
			$stmt = $con->prepare('INSERT INTO courseInfo(ci_name, ci_info, ci_price, ci_img, mi_id, ci_cata) VALUES(:ci_name, :ci_info, :ci_price, :ci_img, :mi_id, :ci_cata)');
			$stmt->bindParam(':ci_name', $ci_name);
			$stmt->bindParam(':ci_info', $ci_info);
			$stmt->bindParam(':ci_price', $ci_price);
			$stmt->bindParam(':ci_img', $ci_img);
			$stmt->bindParam(':mi_id', $mi_id);
			$stmt->bindParam(':ci_cata', $ci_cata);
					
			// SQL문을 실행하여 데이터를 MySQL 서버의 MemberInfo 테이블에 저장
			if($stmt->execute()){
					echo "1";
			}else{
					echo "-1";
			}		 
				
        }catch(PDOException $e) {
                die("Database error: " . $e->getMessage()); 
         }
    } else {
		echo "not post";
	}

?>
