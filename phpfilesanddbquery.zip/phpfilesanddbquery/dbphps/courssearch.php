<?php  
    error_reporting(E_ALL); 
    ini_set('display_errors',1); 
    include('dbcon.php');

    $sch1=$_GET['sch1'];
    $sch2=$_GET['sch2'];	
	$sch3 = $_GET['sch3'];

	try{
		$sql = "select * from courseinfo where ci_cata like '%$sch1%@%' and ci_cata like '%@%$sch2%@%' and ci_cata like '%@%$sch3%'";
		$stmt = $con->prepare($sql);
		$stmt->execute();
					
		// SQL문을 실행하여 데이터를 MySQL 서버의 MemberInfo 테이블에 저장
		if ($stmt->rowCount() == 0){
			die("failed");
		}else{
			$data = array();
			while($row=$stmt->fetch(PDO::FETCH_ASSOC)){
				// FETCH_ASSOC는 행의 값들을 가져올 수 있다.
				extract($row);
					array_push($data, 
					array(
						'ci_idx'=>$row["ci_idx"],
						'ci_name'=>$row["ci_name"],
						'ci_info'=>$row["ci_info"],
						'ci_price'=>$row["ci_price"],
						'ci_img'=>$row["ci_img"],
						'ci_grade'=>$row["ci_grade"],
						'mi_id' => $row["mi_id"],
						'ci_cata'=>$row["ci_cata"],
					));
				}
				header('Content-Type: application/json; charset=utf8');
				$json = json_encode(array("results"=>$data), JSON_PRETTY_PRINT+JSON_UNESCAPED_UNICODE);
				echo $json;
			}
	}catch(PDOException $e) {
            die("Database error: " . $e->getMessage());    
	}
 
 ?>
