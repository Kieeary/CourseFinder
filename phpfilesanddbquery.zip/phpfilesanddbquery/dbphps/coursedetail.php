<?php  
error_reporting(E_ALL); 
ini_set('display_errors',1); 

include('dbcon.php');

$ci_idx=$_GET['ciid'];
 
$sql="select * from v_courseplace where ci_idx ='$ci_idx'";
$stmt = $con->prepare($sql);
$stmt->execute();
if ($stmt->rowCount() == 0){
	die("failed");
}else{
	$data = array();
      while($row=$stmt->fetch(PDO::FETCH_ASSOC)){
		// FETCH_ASSOC는 행의 값들을 가져올 수 있다.
		extract($row);
			array_push($data, 
			array(
				'ci_idx'=>$row["ci_idx"],
				'ci_name'=>$row["ci_name"],
				'mi_id'=>$row["mi_id"],
				'ci_grade'=>$row["ci_grade"],
				'ci_price'=>$row["ci_price"],
				'ci_info'=>$row["ci_info"],
				'cp_order'=>$row["cp_order"],
				'cp_name'=>$row["cp_name"],
				'cp_la'=>$row["cp_la"],
				'cp_lt'=>$row["cp_lt"],
				'cp_addr' => $row["cp_addr"],
				'cp_cata'=>$row["cp_cata"],
			));
	}
	header('Content-Type: application/json; charset=utf8');
    $json = json_encode(array("results"=>$data), JSON_PRETTY_PRINT+JSON_UNESCAPED_UNICODE);
    echo $json;
}
?>
