<?php  
    error_reporting(E_ALL); 
    ini_set('display_errors',1); 
    include('dbcon.php');

	// post방식으로 가져왔는가?
    if( $_SERVER['REQUEST_METHOD'] == 'POST') {

        // 안드로이드 코드의 postParameters 변수에 적어준 이름을 통해서 전달 받음

		$cp_order = $_POST['order'];
		$cp_name = $_POST['pname'];
		$cp_la = $_POST['la'];
		$cp_lt = $_POST['lt'];
		$cp_addr = $_POST['addr'];
		$cp_cata = $_POST['cata'];
		$cp_img = isset($_POST['pimg']) ? $_POST['pimg'] : '';


		try{		
			$stmt = $con->prepare('INSERT INTO CoursePlace(ci_id, cp_order, cp_name, cp_la, cp_lt, cp_addr, cp_img , cp_cata) VALUES((select max(ci_idx) from courseinfo), :cp_order, :cp_name, :cp_la, :cp_lt, :cp_addr, :cp_img, :cp_cata)');
					
				 $stmt->bindParam(':cp_order', $cp_order);
				 $stmt->bindParam(':cp_name', $cp_name);
				 $stmt->bindParam(':cp_la', $cp_la);
				 $stmt->bindParam(':cp_lt', $cp_lt);
				 $stmt->bindParam(':cp_addr', $cp_addr);
				 $stmt->bindParam(':cp_img', $cp_img);
				 $stmt->bindParam(':cp_cata', $cp_cata);
					
			// SQL문을 실행하여 데이터를 MySQL 서버의 MemberInfo 테이블에 저장
			if($stmt->execute()){
					echo "1";
			}else{
					echo "-1";
			}		 
				
        }catch(PDOException $e) {
                die("Database error: " . $e->getMessage()); 
         }
    } else {
		echo "not post";
	}

?>
